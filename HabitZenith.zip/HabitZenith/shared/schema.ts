import { sql } from "drizzle-orm";
import { pgTable, text, varchar, integer, boolean, timestamp, date } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const habits = pgTable("habits", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: text("name").notNull(),
  description: text("description").notNull().default(""),
  frequency: text("frequency").notNull().default("daily"), // "daily" | "weekly"
  targetCount: integer("target_count").notNull().default(1), // For weekly habits
  isActive: boolean("is_active").notNull().default(true),
  createdAt: timestamp("created_at").notNull().default(sql`now()`),
});

export const habitCompletions = pgTable("habit_completions", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  habitId: varchar("habit_id").notNull().references(() => habits.id),
  completedAt: timestamp("completed_at").notNull().default(sql`now()`),
  date: date("date").notNull(), // Date for tracking daily completions
});

export const insertHabitSchema = createInsertSchema(habits).omit({
  id: true,
  createdAt: true,
});

export const insertHabitCompletionSchema = createInsertSchema(habitCompletions).omit({
  id: true,
  completedAt: true,
});

export type InsertHabit = z.infer<typeof insertHabitSchema>;
export type Habit = typeof habits.$inferSelect;
export type InsertHabitCompletion = z.infer<typeof insertHabitCompletionSchema>;
export type HabitCompletion = typeof habitCompletions.$inferSelect;

// Extended types for frontend use
export type HabitWithStats = Habit & {
  currentStreak: number;
  longestStreak: number;
  completedToday: boolean;
  thisWeekCompletions: number;
  totalCompletions: number;
};

export type DashboardStats = {
  todayProgress: { completed: number; total: number };
  weeklyProgress: { completed: number; total: number };
  longestStreak: number;
  successRate: number;
  totalDays: number;
};
